"""
SecureNet Scanner — Flask Backend
Real socket-based port scanner with banner grabbing, OS hints, and SSE streaming.
Run: python app.py
"""

import socket
import concurrent.futures
import json
import time
import re
import ipaddress
from datetime import datetime
from flask import Flask, render_template, request, Response, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ─── Service map ──────────────────────────────────────────────────────────────
SERVICE_MAP = {
    20:"FTP-Data", 21:"FTP", 22:"SSH", 23:"Telnet", 25:"SMTP", 53:"DNS",
    67:"DHCP", 68:"DHCP", 69:"TFTP", 80:"HTTP", 88:"Kerberos", 110:"POP3",
    111:"RPC", 119:"NNTP", 123:"NTP", 135:"MSRPC", 137:"NetBIOS", 138:"NetBIOS",
    139:"NetBIOS", 143:"IMAP", 161:"SNMP", 162:"SNMP", 179:"BGP", 389:"LDAP",
    443:"HTTPS", 445:"SMB", 465:"SMTPS", 514:"Syslog", 587:"SMTP",
    636:"LDAPS", 993:"IMAPS", 995:"POP3S", 1080:"SOCKS", 1194:"OpenVPN",
    1433:"MSSQL", 1521:"Oracle DB", 1723:"PPTP", 1883:"MQTT", 2049:"NFS",
    2181:"ZooKeeper", 2375:"Docker", 3000:"Dev Server", 3306:"MySQL",
    3389:"RDP", 4000:"Dev", 4443:"HTTPS-alt", 5000:"Flask/Dev",
    5432:"PostgreSQL", 5900:"VNC", 6379:"Redis", 7001:"WebLogic",
    8000:"HTTP-alt", 8080:"HTTP-Proxy", 8443:"HTTPS-alt", 8888:"Jupyter",
    9000:"PHP-FPM", 9090:"Prometheus", 9092:"Kafka", 9200:"Elasticsearch",
    9443:"HTTPS-alt", 10000:"Webmin", 11211:"Memcached",
    27017:"MongoDB", 50070:"Hadoop"
}

SCAN_PROFILES = {
    "quick":  [21,22,23,25,53,80,110,135,139,143,443,445,993,995,1723,3306,3389,5900,8080,8443],
    "common": [20,21,22,23,25,53,80,88,110,111,119,123,135,137,139,143,161,389,443,445,
               465,587,636,993,995,1080,1433,1521,1723,1883,2049,2181,2375,3000,3306,
               3389,4443,5000,5432,5900,6379,7001,8000,8080,8443,8888,9000,9090,9200,
               9443,10000,11211,27017],
    "full":   list(range(1, 1025))
}

# ─── Core scanner ─────────────────────────────────────────────────────────────

def resolve_target(target: str):
    """Resolve hostname to IP, validate."""
    target = target.strip()
    try:
        ipaddress.ip_address(target)
        ip = target
    except ValueError:
        try:
            ip = socket.gethostbyname(target)
        except socket.gaierror:
            return None, f"Cannot resolve hostname: {target}"
    return ip, None


def grab_banner(ip: str, port: int, timeout: float = 2.0) -> str:
    """Try to grab a service banner."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((ip, port))
            # Send HTTP request for web ports
            if port in (80, 8080, 8000, 8081, 8082, 8888, 3000):
                s.send(b"HEAD / HTTP/1.0\r\nHost: target\r\n\r\n")
            elif port in (443, 8443, 4443):
                return "TLS/SSL"
            else:
                s.send(b"\r\n")
            banner = s.recv(1024).decode("utf-8", errors="replace").strip()
            # Trim to first line
            banner = banner.split("\n")[0][:80].strip()
            return banner if banner else ""
    except Exception:
        return ""


def probe_port(ip: str, port: int, timeout: float = 1.5):
    """
    Attempt TCP connect to (ip, port).
    Returns dict: {port, state, latency_ms, banner, service}
    """
    service = SERVICE_MAP.get(port, f"port-{port}")
    start = time.perf_counter()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            latency = round((time.perf_counter() - start) * 1000, 1)
            if result == 0:
                banner = grab_banner(ip, port)
                return {"port": port, "state": "open", "latency_ms": latency,
                        "banner": banner, "service": service}
            else:
                return {"port": port, "state": "closed", "latency_ms": latency,
                        "banner": "", "service": service}
    except socket.timeout:
        latency = round((time.perf_counter() - start) * 1000, 1)
        return {"port": port, "state": "filtered", "latency_ms": latency,
                "banner": "", "service": service}
    except Exception as e:
        return {"port": port, "state": "error", "latency_ms": 0,
                "banner": str(e)[:40], "service": service}


def detect_os_hint(open_ports: list, banners: dict) -> str:
    """Guess OS from open ports and banners — heuristic only."""
    ports_set = set(open_ports)
    all_banners = " ".join(banners.values()).lower()

    if 3389 in ports_set or 445 in ports_set or 135 in ports_set:
        return "Windows (RDP/SMB/RPC detected)"
    if 22 in ports_set:
        if "ubuntu" in all_banners:   return "Linux — Ubuntu"
        if "debian" in all_banners:   return "Linux — Debian"
        if "centos" in all_banners:   return "Linux — CentOS"
        if "openssh" in all_banners:  return "Linux/Unix (OpenSSH)"
    if 548 in ports_set:
        return "macOS (AFP detected)"
    if ports_set & {80, 443, 8080}:
        if "nginx" in all_banners:    return "Linux — Nginx server"
        if "apache" in all_banners:   return "Linux — Apache server"
        if "iis" in all_banners:      return "Windows — IIS server"
    if open_ports:
        return "Unknown OS"
    return "No hint available"


# ─── SSE Scan endpoint ────────────────────────────────────────────────────────

def scan_generator(target: str, ports: list, workers: int = 100, timeout: float = 1.5):
    """Generator that yields SSE events as ports are scanned."""

    def sse(event: str, data: dict) -> str:
        return f"event: {event}\ndata: {json.dumps(data)}\n\n"

    ip, err = resolve_target(target)
    if err:
        yield sse("error", {"message": err})
        return

    yield sse("start", {
        "ip": ip,
        "target": target,
        "total": len(ports),
        "timestamp": datetime.now().isoformat()
    })

    open_ports = []
    banners = {}
    open_count = 0
    filtered_count = 0
    scanned = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {executor.submit(probe_port, ip, p, timeout): p for p in ports}

        for future in concurrent.futures.as_completed(future_map):
            result = future.result()
            scanned += 1

            if result["state"] == "open":
                open_count += 1
                open_ports.append(result["port"])
                if result["banner"]:
                    banners[str(result["port"])] = result["banner"]
                yield sse("port", result)

            elif result["state"] == "filtered":
                filtered_count += 1
                yield sse("port", result)

            # Progress every 5 ports
            if scanned % 5 == 0 or scanned == len(ports):
                yield sse("progress", {
                    "scanned": scanned,
                    "total": len(ports),
                    "open": open_count,
                    "filtered": filtered_count
                })

    os_hint = detect_os_hint(open_ports, banners)
    yield sse("done", {
        "ip": ip,
        "target": target,
        "total_scanned": scanned,
        "open": open_count,
        "filtered": filtered_count,
        "closed": scanned - open_count - filtered_count,
        "os_hint": os_hint,
        "timestamp": datetime.now().isoformat()
    })


@app.route("/scan")
def scan():
    target = request.args.get("target", "").strip()
    profile = request.args.get("profile", "quick")
    custom = request.args.get("custom", "")
    timeout = float(request.args.get("timeout", "1.5"))
    workers = int(request.args.get("workers", "100"))

    if not target:
        return jsonify({"error": "No target provided"}), 400

    if profile == "custom" and custom:
        ports = []
        for p in custom.split(","):
            p = p.strip()
            if "-" in p:
                lo, hi = p.split("-", 1)
                try:
                    ports.extend(range(int(lo), int(hi) + 1))
                except ValueError:
                    pass
            else:
                try:
                    ports.append(int(p))
                except ValueError:
                    pass
        ports = [p for p in ports if 1 <= p <= 65535]
    else:
        ports = SCAN_PROFILES.get(profile, SCAN_PROFILES["quick"])

    return Response(
        scan_generator(target, ports, workers=workers, timeout=timeout),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no"
        }
    )


@app.route("/ping")
def ping():
    target = request.args.get("target", "").strip()
    if not target:
        return jsonify({"error": "No target"}), 400
    ip, err = resolve_target(target)
    if err:
        return jsonify({"alive": False, "error": err})
    start = time.perf_counter()
    reachable = probe_port(ip, 80, timeout=1.0)["state"] == "open" or \
                probe_port(ip, 443, timeout=1.0)["state"] == "open" or \
                probe_port(ip, 22, timeout=1.0)["state"] == "open"
    latency = round((time.perf_counter() - start) * 1000, 1)
    return jsonify({"alive": reachable, "ip": ip, "latency_ms": latency})


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    print("SecureNet Scanner running at http://localhost:5000")
    app.run(debug=True, threaded=True, host="0.0.0.0", port=5000)
