/* SecureNet Scanner — Frontend JS */

let evtSource = null;
let results = [];
let rowIndex = 0;
let scanning = false;

// ─── Server health check ───────────────────────────────────────────────────
async function checkServer() {
  try {
    const r = await fetch('/ping?target=localhost', { signal: AbortSignal.timeout(2000) });
    if (r.ok) {
      document.getElementById('serverDot').className = 'status-dot online';
      document.getElementById('serverStatus').textContent = 'Backend live';
    }
  } catch {
    document.getElementById('serverDot').className = 'status-dot offline';
    document.getElementById('serverStatus').textContent = 'Backend offline';
  }
}
checkServer();
setInterval(checkServer, 15000);

// ─── Profile selector ─────────────────────────────────────────────────────
document.getElementById('profileSel').addEventListener('change', function () {
  document.getElementById('customWrap').style.display =
    this.value === 'custom' ? 'flex' : 'none';
});

// ─── Logging ──────────────────────────────────────────────────────────────
function log(msg, cls = '') {
  const w = document.getElementById('logBody');
  const d = document.createElement('div');
  if (cls) d.className = cls;
  const t = new Date().toLocaleTimeString();
  d.textContent = `[${t}]  ${msg}`;
  w.appendChild(d);
  w.scrollTop = w.scrollHeight;
  if (w.children.length > 200) w.removeChild(w.firstChild);
}

// ─── Stats helpers ────────────────────────────────────────────────────────
function setStatus(label, cls) {
  document.getElementById('statusBadge').innerHTML =
    `<span class="badge badge-${cls}">${label}</span>`;
}

function updateStats(open, filtered, scanned, total) {
  document.getElementById('openCount').textContent = open;
  document.getElementById('filtCount').textContent = filtered;
  document.getElementById('scannedCount').textContent =
    total ? `${scanned} / ${total}` : scanned;
  document.getElementById('progBar').style.width =
    total ? Math.round((scanned / total) * 100) + '%' : '0%';
}

// ─── Result row ───────────────────────────────────────────────────────────
function addRow(data) {
  const empty = document.getElementById('emptyState');
  if (empty) empty.remove();

  rowIndex++;
  const body = document.getElementById('resultsBody');
  const row = document.createElement('div');
  const stateClass =
    data.state === 'open' ? 'open-row' :
    data.state === 'filtered' ? 'filtered-row' : '';
  const stateBadge =
    data.state === 'open' ? 'state-open' :
    data.state === 'filtered' ? 'state-filtered' : 'state-closed';
  const hasBanner = data.banner && data.banner.length > 0;

  row.className = `result-row ${stateClass}`;
  row.innerHTML = `
    <span style="color:var(--muted);font-family:var(--mono);font-size:.75rem">${rowIndex}</span>
    <span class="port-num">${data.port}</span>
    <span class="svc-name">${data.service}</span>
    <span><span class="state-badge ${stateBadge}">${data.state}</span></span>
    <span class="latency">${data.latency_ms}ms</span>
    <span class="banner-text ${hasBanner ? 'has-banner' : ''}">${hasBanner ? data.banner : '—'}</span>
  `;
  body.appendChild(row);
  body.scrollTop = body.scrollHeight;
  results.push(data);
}

// ─── Start scan ───────────────────────────────────────────────────────────
function startScan() {
  const target = document.getElementById('targetInput').value.trim();
  if (!target) { log('No target specified.', 'log-err'); return; }
  if (scanning) return;

  // Reset UI
  scanning = true;
  results = [];
  rowIndex = 0;
  document.getElementById('resultsBody').innerHTML = '';
  document.getElementById('logBody').innerHTML = '';
  document.getElementById('progBar').style.width = '0%';
  document.getElementById('osHint').textContent = '—';
  document.getElementById('exportBtn').disabled = true;
  document.getElementById('scanBtn').disabled = true;
  document.getElementById('stopBtn').style.display = 'inline-flex';

  const profile = document.getElementById('profileSel').value;
  const custom = document.getElementById('customInput').value;
  const timeout = document.getElementById('timeoutInput').value;

  let url = `/scan?target=${encodeURIComponent(target)}&profile=${profile}&timeout=${timeout}`;
  if (profile === 'custom') url += `&custom=${encodeURIComponent(custom)}`;

  setStatus('Scanning…', 'scanning');
  updateStats(0, 0, 0, 0);
  log(`Target: ${target}`, 'log-info');
  log(`Profile: ${profile}`, 'log-info');

  evtSource = new EventSource(url);

  evtSource.addEventListener('start', (e) => {
    const d = JSON.parse(e.data);
    log(`Resolved to ${d.ip} — scanning ${d.total} ports`, 'log-ok');
    updateStats(0, 0, 0, d.total);
  });

  evtSource.addEventListener('port', (e) => {
    const d = JSON.parse(e.data);
    if (d.state === 'open') {
      addRow(d);
      log(`Port ${d.port} (${d.service}) is OPEN  [${d.latency_ms}ms]${d.banner ? '  → ' + d.banner : ''}`, 'log-ok');
    } else if (d.state === 'filtered') {
      addRow(d);
      log(`Port ${d.port} filtered`, '');
    }
  });

  evtSource.addEventListener('progress', (e) => {
    const d = JSON.parse(e.data);
    updateStats(d.open, d.filtered, d.scanned, d.total);
  });

  evtSource.addEventListener('done', (e) => {
    const d = JSON.parse(e.data);
    setStatus('Complete', 'done');
    document.getElementById('progBar').style.width = '100%';
    document.getElementById('osHint').textContent = d.os_hint || '—';
    updateStats(d.open, d.filtered, d.total_scanned, d.total_scanned);
    log(`Scan complete — ${d.open} open, ${d.filtered} filtered, ${d.closed} closed`, 'log-ok');
    if (d.open === 0) log('No open ports found — host may be firewalled or offline.', 'log-warn');
    if (d.open > 10) log(`High port exposure (${d.open} open ports). Review your firewall rules.`, 'log-warn');
    log(`OS hint: ${d.os_hint}`, 'log-info');
    if (results.length === 0) {
      document.getElementById('resultsBody').innerHTML = `
        <div class="empty-state">
          <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          <div>No open or filtered ports found</div>
        </div>`;
    }
    document.getElementById('exportBtn').disabled = results.length === 0;
    finishScan();
  });

  evtSource.addEventListener('error', (e) => {
    try {
      const d = JSON.parse(e.data);
      log(`Error: ${d.message}`, 'log-err');
      setStatus('Error', 'error');
    } catch {
      if (!scanning) return;
      log('Connection to backend lost.', 'log-err');
      setStatus('Error', 'error');
    }
    finishScan();
  });
}

// ─── Stop scan ────────────────────────────────────────────────────────────
function stopScan() {
  if (evtSource) {
    evtSource.close();
    evtSource = null;
  }
  log(`Scan stopped by user.`, 'log-warn');
  setStatus('Stopped', 'stopped');
  document.getElementById('exportBtn').disabled = results.length === 0;
  finishScan();
}

function finishScan() {
  scanning = false;
  if (evtSource) { evtSource.close(); evtSource = null; }
  document.getElementById('scanBtn').disabled = false;
  document.getElementById('stopBtn').style.display = 'none';
}

// ─── Export CSV ───────────────────────────────────────────────────────────
function exportCSV() {
  if (!results.length) return;
  const header = 'Port,Service,State,Latency(ms),Banner\n';
  const rows = results.map(r =>
    `${r.port},"${r.service}",${r.state},${r.latency_ms},"${(r.banner || '').replace(/"/g, '""')}"`
  ).join('\n');
  const target = document.getElementById('targetInput').value.trim().replace(/[^a-z0-9.\-]/gi, '_');
  const ts = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
  const blob = new Blob([header + rows], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `securenet_${target}_${ts}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
  log('Exported results to CSV.', 'log-info');
}

// ─── Hero terminal demo ───────────────────────────────────────────────────
(function heroDemo() {
  const lines = [
    { t: 'p', v: '$ python app.py' },
    { t: 'ok', v: '[OK]  SecureNet running → http://localhost:5000' },
    { t: 'info', v: '[INFO] Loaded 50 port profiles' },
    { t: 'dim', v: '' },
    { t: 'p', v: '$ # User scans 192.168.1.1 via browser...' },
    { t: 'info', v: '[INFO] Resolving 192.168.1.1 ...' },
    { t: 'ok',  v: '[OK]  TCP connect → :22 (SSH)  [4.2ms]' },
    { t: 'ok',  v: '[OK]  TCP connect → :80 (HTTP)  [6.1ms]' },
    { t: 'warn', v: '[WARN] Port 23 (Telnet) is OPEN — insecure!' },
    { t: 'ok',  v: '[OK]  TCP connect → :443 (HTTPS)  [5.8ms]' },
    { t: 'info', v: '[INFO] Scan complete — 4 open, 16 closed' },
  ];
  const el = document.getElementById('termDemo');
  let i = 0;
  function next() {
    if (i >= lines.length) return;
    const ln = lines[i++];
    const d = document.createElement('div');
    d.className = `tl-${ln.t}`;
    d.textContent = ln.v || '\u00a0';
    el.appendChild(d);
    el.scrollTop = el.scrollHeight;
    setTimeout(next, 400 + Math.random() * 300);
  }
  setTimeout(next, 800);
})();

// Allow Enter key on target input
document.getElementById('targetInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !scanning) startScan();
});
