# SecureNet — Network Port Scanner

A real-time network port scanner with a Python/Flask backend and a dark-themed web UI.

## Features
- Real TCP socket scanning (actual network packets)
- Parallel scanning with ThreadPoolExecutor (100 threads)
- Service banner grabbing
- Heuristic OS detection
- Server-Sent Events (SSE) — results stream live to the browser
- Export results as CSV
- 4 scan profiles: Quick (20), Common (50), Full (1–1024), Custom

## Setup

### 1. Install dependencies
```bash
pip install flask flask-cors
```

### 2. Run the server
```bash
python app.py
```

Server starts at: **http://localhost:5000**

### 3. Open in browser
Navigate to `http://localhost:5000` and use the UI.

## API

### GET /scan
Stream scan results via SSE.

| Parameter | Default | Description |
|-----------|---------|-------------|
| target | required | IP address or hostname |
| profile | quick | quick / common / full / custom |
| custom | — | Comma-separated ports or ranges (e.g. 80,443,8080-8090) |
| timeout | 1.5 | Socket timeout in seconds |
| workers | 100 | Concurrent threads |

**Example:**
```bash
curl "http://localhost:5000/scan?target=192.168.1.1&profile=common"
```

**SSE events emitted:**
- `start` — scan begins, IP resolved, total port count
- `port` — one per port result (open/filtered/closed)
- `progress` — every 5 ports, running totals
- `done` — scan complete, OS hint, summary
- `error` — resolution failure or other error

### GET /ping
Quick reachability check.

```bash
curl "http://localhost:5000/ping?target=192.168.1.1"
```

## Legal notice
Only scan hosts you own or have explicit written permission to scan.
Unauthorized port scanning may be illegal in your jurisdiction.

## Project structure
```
scanner/
├── app.py              # Flask backend
├── requirements.txt
├── README.md
├── templates/
│   └── index.html      # Main page
└── static/
    ├── css/style.css
    └── js/scanner.js
```
